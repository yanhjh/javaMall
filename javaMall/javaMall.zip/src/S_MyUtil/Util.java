package S_MyUtil;

import java.util.Scanner;

public class Util {
	static public  Scanner scan = new Scanner(System.in);
}
